const connectButton = document.getElementById("connect");
const mintButton = document.getElementById("mint");

let signer;
let contract;

const contractAddress = "0xYourContractAddressHere"; // Deploy के बाद डालना
const abi = [ /* Contract ABI JSON यहाँ डालना */ ];

connectButton.onclick = async () => {
  if (window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = provider.getSigner();
    contract = new ethers.Contract(contractAddress, abi, signer);
    alert("Wallet Connected!");
  } else {
    alert("Please install MetaMask!");
  }
};

mintButton.onclick = async () => {
  if (contract) {
    const tx = await contract.createNFT(await signer.getAddress());
    await tx.wait();
    alert("NFT Minted Successfully!");
  } else {
    alert("Connect Wallet First!");
  }
};
